Readme
======

Heads-up regarding the following dependencies:

  lodash.js
    Breaking changes in v4.x+, needs migration before
    update from 3.x is possible
  jquery/jquery-ui.js
    Used by jquery-fileupload
  pnotify/*
    Breaking changes and no proper changelog to even be able to figure them out
